<?php
$database= mysqli_connect('localhost','root','','cv');

function query ($query){
     global $database;
    $tampilkan = mysqli_query ($database,$query);
    $wadahkosong = [];
    while($data = mysqli_fetch_assoc ($tampilkan)){
        $wadahkosong [] = $data;
    }
    return $wadahkosong;
}

function tambah1 ($data){
    global $database;
    $nama = $_POST ["nama"];
    $jenis_kelamin = $_POST ["jenis_kelamin"];
    $alamat = $_POST ["alamat"];
    $no_hp = $_POST ["no_hp"];
    $skil = $_POST ["skil"];
    $hobi = $_POST ["hobi"];
    $tambah = "INSERT INTO vindy VALUE
    ('','$nama','$jenis_kelamin','$alamat','$no_hp','$skil','$hobi')";

    mysqli_query($database,$tambah);
    return mysqli_affected_rows($database);
}


function hapus ($hapus){
    global $database;
    mysqli_query ($database, "DELETE FROM vindy where no=$hapus");
    return mysqli_affected_rows($database);
}


?>