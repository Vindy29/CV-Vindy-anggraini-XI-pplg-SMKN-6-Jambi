<?php
$database= mysqli_connect('localhost','root','','cv');

function query ($query){
     global $database;
    $tampilkan = mysqli_query ($database,$query);
    $wadahkosong = [];
    while($data = mysqli_fetch_assoc ($tampilkan)){
        $wadahkosong [] = $data;
    }
    return $wadahkosong;
}

function tambah1 ($data){
    global $database;
    $nama = $_POST ["nama"];
    $jenis_kelamin = $_POST ["jenis_kelamin"];
    $alamat = $_POST ["alamat"];
    $no_hp = $_POST ["no_hp"];
    $skil = $_POST ["skil"];
    $hobi = $_POST ["hobi"];
    $pendidikan = $_POST ["pendidikan"];
    $pekerjaan = $_POST ["pekerjaan"];
    $tambah = "INSERT INTO vindy VALUE
    ('','$nama','$jenis_kelamin','$alamat','$no_hp','$skil','$hobi','$pendidikan','$pekerjaan')";

    mysqli_query($database,$tambah);
    return mysqli_affected_rows($database);
}


function hapus ($hapus){
    global $database;
    mysqli_query ($database, "DELETE FROM vindy where no=$hapus");
    return mysqli_affected_rows($database);
}
function edit ($edit){
    global $database;
    $hapus=$_GET["no"];

    $nama = $_POST ["nama"];
    $jenis_kelamin = $_POST ["jenis_kelamin"];
    $alamat = $_POST ["alamat"];
    $no_hp = $_POST ["no_hp"];
    $skil = $_POST ["skil"];
    $hobi = $_POST ["hobi"];
    $pendidikan = $_POST ["pendidikan"];
    $pekerjaan = $_POST ["pekerjaan"];
    $edit = "update vindy set
    nama = '$nama',
    jenis_kelamin = '$jenis_kelamin',
    alamat = '$alamat',
    no_hp = '$no_hp',
    skil = '$skil',
    hobi = '$hobi',
    pendidikan = '$pendidikan',
    pekerjaan = '$pekerjaan'
    where no =$hapus";
    mysqli_query($database,$edit);
    return mysqli_affected_rows($database);
}


?>