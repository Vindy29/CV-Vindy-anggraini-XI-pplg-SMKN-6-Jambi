<?php
session_start();
if (!isset($_SESSION["login"]) ){
    header ("Location: login.php");
        exit;
}
require 'function.php';

$hapus = $_GET ["no"]; //fungsi hapus
$data= mysqli_query ($database,"SELECT*FROM vindy WHERE no=$hapus");

if(isset ($_POST["tombol"])){

    
    //cek apabila data sudah tersimpan
    if (mysqli_affected_rows($database)>0){
        echo "<script>
        alert ('Data Berhasil Diubah');
        document.location.href='index.php';
        </script>";
    } else{
        echo "<script>
        alert ('Data Gagal Diubah');
        document.location.href='index.php';
        </script>";
    }
}

?>
<!DOCTYPE html>
<head>
    <title>Edit Data</title>
</head>
<body>

<?php
    while($cari= mysqli_fetch_assoc ($data)):
    ?>
    <h2>Edit Data</h2>
    <form method="POST">
    <ul>

<li><label >nama</label></li>
<li><input type="text" name="nama" value="<?= $cari ["nama"]?>"></li>


    <li><label >jenis_kelamin</label></li>
    <li><input type="text" name="jenis_kelamin" value="<?= $cari ["jenis_kelamin"]?>"></li>


    <li><label >alamat</label></li>
    <li><input type="text" name="alamat" value="<?= $cari ["alamat"]?>"></li>
    <li><label >no hp</label></li>
    <li><input type="text" name="no_hp" value="<?php echo $cari ["no_hp"]?>"></li>
    <li><label >skil</label></li>
    <li><input type="text" name="skil" value="<?php echo $cari ["skil"]?>"></li>
    <li><label >hobi</label></li>
    <li><input type="text" name="hobi" value="<?php echo $cari ["hobi"]?>"></li>

    <li><label> pendidikan </label></li>
    <li><textarea name="pendidikan" id=""><?php echo $cari ["pendidikan"]?></textarea></li>

    <li><label> pekerjaan </label></li>
    <li><textarea name="pekerjaan" id=""><?php echo $cari ["pekerjaan"]?></textarea></li>

    <li><button type="submit" name="tombol">Perbaharuin data</button></li>
</ul>
<?php
    endwhile;
    ?>
    </form>
</body>
</html>