<?php
session_start();
if (!isset($_SESSION["login"]) ){
    header ("Location: login.php");
        exit;
}

require 'function.php';
$cari= mysqli_query ($database,"SELECT*FROM barang");
if (isset ($_POST["tombol"])){
    $Pencarian= $_POST ["pencarian"];
    $datayangdicari= "SELECT *FROM barang WHERE
    nama_hotel like '%$Pencarian%' or
   tipe like '%$Pencarian%'";
    $cari= mysqli_query ($database,$datayangdicari);
} else {
    $cari= mysqli_query ($database,'SELECT*FROM barang');
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tugas</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="header">
    <div id="logo-atas">
<img src="logo.png" alt="Logo Sekolah">
    </div>
    <div id="header-title">
<a href="index.php">hotel</a>
    </div>
    </div>
<ul class="menu">
    <li class="menu-item"><a href="index.php">Beranda</a></li>
    <li class="menu-item"><a href="index.php">Data</a></li>
    <li class="menu-item"><a href="index.php">tambah_data</a></li>
    <li class="menu-item"><a href="index.php">Tentang Kami</a></li>
    <li class="menu-item"><a href="login.php">Keluar</a></li>
</ul>
<div class="konten">
    <h2>Apa itu hotel digital(E-HOTEL)?</h2>
    <p>hotel digital (digital library atau E-library)adalah tempat dimana anda dapat membeli hotel secara digital
        diera digital seperti sekarang inianda dapat dengan mudah memesan kamar,hotel digital punya beberapa keunggulan dan kelemahan.berikut informasinya.</p>
        <h2>keunggulan digital hotel</h2>
        <p>tentu saja segala sesuatu yang bersifat digital memudahkan manusia.hal ini juga berlaku untuk hotel digital.</p>
        <p>1.praktis dan tidak terbatas oleh waktu</p>
        <p>2.tidak membuat anda susah saat memesan kamar</p>
</div>
<div class="fotter">
    <p>Hak Cipta 2025 . Pengembangan Perangkat Lunak dan Gim</p>
</div>
</body>
</html> 