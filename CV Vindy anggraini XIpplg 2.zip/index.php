<?php
require 'function.php';
$cari= mysqli_query ($database,"SELECT*FROM vindy");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>vindy</title>
    <link rel="stylesheet" href="style.css">

</head>
<body>
    <div class="container">
        <div class="header">
        <div class="gambar"> <img src="gambar.jpg" alt="ini gambar saya">
            </div>

            <?php
    foreach ($cari as $cari2):
    ?>

            <h1><?php echo $cari2 ['nama'];?></h1>
            <h3>Memasak</h3>
            <?php
    endforeach;
    ?>

        </div>
        <div class="main">
            <div class="left">
            <h2>Informasi Identitas</h2>
            <p><strong>Nama</strong> <?= $cari2['nama'];?></p>
            <p><strong>Jenis Kelamin</strong> <?= $cari2['jenis_kelamin'];?></p>
            <p><strong>Alamat</strong> <?= $cari2['alamat'];?></p>
            <p><strong>No Hp</strong> <?= $cari2['no_hp'];?></p>
            <p><strong>Skil</strong> <?= $cari2['skil'];?></p>
            <p><strong>Hobi</strong> <?= $cari2['hobi'];?></p>
            <h2>Pendidikan</h2>
            <p><strong><?=$cari2['pendidikan'] ?></strong></p>
            </div>
            <div class="right">
                <h2>Pekerjaan</h2>
                <p><strong><?=$cari2['pekerjaan'] ?></strong></p>
                <h3>Kepribadian</h3>
                <p><strong>Sifat</strong> Saya</p>
                <li>Lemah Lembut</li>
                <li>Tidak suka marah marah</li>
            </div>
        </div>
    </div>
</body>
</html>